const express = require('express');
const router = express.Router();
const Stripe = require('stripe');
const db = require('../db');

// See routes/checkout.js for why this is conditional — constructing Stripe with an
// empty key throws immediately in newer versions of the SDK.
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

// POST /api/webhooks/stripe
// Stripe calls this URL directly (not the browser), so it's the trustworthy place to
// actually record a paid booking. Registered in server.js with express.raw() BEFORE
// express.json(), because Stripe's signature check needs the exact raw request body.
router.post('/stripe', (req, res) => {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) {
    console.warn('Received a Stripe webhook call, but Stripe is not configured on this server yet.');
    return res.status(500).send('Stripe not configured');
  }
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    try {
      createBookingFromSession(session);
    } catch (err) {
      // Log and still 200 the webhook — Stripe retries on non-2xx, and retrying a
      // booking-creation bug won't fix the bug. Investigate from the server logs instead.
      console.error('Failed to create booking from Stripe session:', err);
    }
  }

  res.json({ received: true });
});

function createBookingFromSession(session) {
  const meta = session.metadata || {};
  const items = JSON.parse(meta.items || '[]');
  if (!items.length) return;

  const member = meta.memberId
    ? db.prepare('SELECT * FROM members WHERE id = ?').get(meta.memberId)
    : null;

  const baseTotal = items.reduce((s, it) => s + it.unitTotal, 0);
  const discount = member ? +(baseTotal * 0.03).toFixed(2) : 0;
  let afterDiscount = +(baseTotal - discount).toFixed(2);
  let rewardUsed = 0;
  if (member && meta.useReward === '1') {
    rewardUsed = +Math.min(member.reward, afterDiscount).toFixed(2);
    afterDiscount = +(afterDiscount - rewardUsed).toFixed(2);
  }
  const rewardEarned = member ? +(afterDiscount * 0.03).toFixed(2) : 0;

  const insertBooking = db.prepare(`
    INSERT INTO bookings
      (customer_name, customer_email, customer_phone, session, date, time, qty,
       base_total, discount, reward_used, reward_earned, total_paid,
       payment_method, promo_code, member_id, status)
    VALUES (@customer_name, @customer_email, @customer_phone, @session, @date, @time, @qty,
            @base_total, @discount, @reward_used, @reward_earned, @total_paid,
            'stripe', @promo_code, @member_id, 'confirmed')
  `);

  const tx = db.transaction(() => {
    items.forEach((it) => {
      const share = baseTotal > 0 ? it.unitTotal / baseTotal : 0;
      insertBooking.run({
        customer_name: meta.name,
        customer_email: meta.email,
        customer_phone: meta.phone || null,
        session: it.session,
        date: it.date,
        time: it.time,
        qty: it.flat ? '—' : String(it.qty ?? ''),
        base_total: it.unitTotal,
        discount: +(discount * share).toFixed(2),
        reward_used: +(rewardUsed * share).toFixed(2),
        reward_earned: +(rewardEarned * share).toFixed(2),
        total_paid: +((it.unitTotal - discount * share - rewardUsed * share)).toFixed(2),
        promo_code: meta.promoCode || null,
        member_id: member ? member.id : null,
      });
    });
    if (member) {
      db.prepare('UPDATE members SET reward = reward - ? + ? WHERE id = ?')
        .run(rewardUsed, rewardEarned, member.id);
    }
  });
  tx();
}

module.exports = router;
