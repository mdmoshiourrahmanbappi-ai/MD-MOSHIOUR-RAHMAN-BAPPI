const express = require('express');
const router = express.Router();
const Stripe = require('stripe');
const db = require('../db');

// Only construct the Stripe client if a key is actually configured — the newer Stripe
// SDK throws immediately on `new Stripe('')`, which would otherwise crash the whole
// server at startup before Stripe is set up. See the /api/checkout/create-session
// handler below for the friendly error this produces instead.
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

// POST /api/checkout/create-session
// Body: { name, email, phone, useReward, promoCode, items: [{session,date,time,qty,unitTotal,flat}] }
//
// Pricing is computed server-side here too (never trust the browser), exactly the same
// way routes/bookings.js does it. The booking itself is NOT created yet — it's created by
// the webhook below, once Stripe confirms the money actually moved. This is the standard
// "Checkout Session" pattern: the customer's card details never touch this server at all.
router.post('/create-session', async (req, res) => {
  if (!stripe) {
    return res.status(500).json({ error: 'Stripe is not configured on this server yet (missing STRIPE_SECRET_KEY).' });
  }
  const { name, email, phone, useReward, promoCode, items } = req.body || {};
  if (!name || !email || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'name, email and at least one item are required' });
  }

  const member = db.prepare('SELECT * FROM members WHERE lower(email) = lower(?)').get(email);
  const baseTotal = items.reduce((s, it) => s + it.unitTotal, 0);
  const discount = member ? +(baseTotal * 0.03).toFixed(2) : 0;
  let afterDiscount = +(baseTotal - discount).toFixed(2);
  let rewardUsed = 0;
  if (member && useReward) {
    rewardUsed = +Math.min(member.reward, afterDiscount).toFixed(2);
    afterDiscount = +(afterDiscount - rewardUsed).toFixed(2);
  }
  if (afterDiscount <= 0) {
    return res.status(400).json({ error: 'Total must be greater than zero to check out with Stripe.' });
  }

  const origin = req.headers.origin || `${req.protocol}://${req.get('host')}`;

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      customer_email: email,
      line_items: [
        {
          price_data: {
            currency: 'gbp',
            product_data: { name: 'Kidz Nest Play Café booking' },
            unit_amount: Math.round(afterDiscount * 100), // Stripe wants pence
          },
          quantity: 1,
        },
      ],
      // Everything the webhook needs to create the booking after payment succeeds.
      // Stripe's metadata values must be strings, so the item list is JSON-encoded.
      metadata: {
        name,
        email,
        phone: phone || '',
        promoCode: promoCode || '',
        memberId: member ? member.id : '',
        useReward: useReward ? '1' : '0',
        items: JSON.stringify(items),
      },
      success_url: `${origin}/?booking=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/?booking=cancelled`,
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error('Stripe session creation failed:', err.message);
    res.status(500).json({ error: 'Could not start checkout. Please try again.' });
  }
});

// GET /api/checkout/session/:id — lets the success page confirm what was booked
router.get('/session/:id', async (req, res) => {
  if (!stripe) {
    return res.status(500).json({ error: 'Stripe is not configured on this server yet.' });
  }
  try {
    const session = await stripe.checkout.sessions.retrieve(req.params.id);
    const bookings = db.prepare(
      "SELECT * FROM bookings WHERE payment_method = 'stripe' AND customer_email = lower(?) ORDER BY created_at DESC LIMIT 10"
    ).all(session.customer_email || session.metadata.email);
    res.json({ paid: session.payment_status === 'paid', bookings });
  } catch (err) {
    res.status(404).json({ error: 'Session not found' });
  }
});

module.exports = router;
