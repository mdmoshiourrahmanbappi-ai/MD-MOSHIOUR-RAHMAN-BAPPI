const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { requireAdmin, JWT_SECRET } = require('../middleware/auth');

// POST /api/admin/login  { username, password }
router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.prepare('SELECT * FROM admin_users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password || '', user.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  const token = jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, { expiresIn: '12h' });
  res.json({ token });
});

// POST /api/admin/change-password  { currentPassword, newPassword }  (auth required)
router.post('/change-password', requireAdmin, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  const user = db.prepare('SELECT * FROM admin_users WHERE id = ?').get(req.admin.sub);
  if (!bcrypt.compareSync(currentPassword || '', user.password_hash)) {
    return res.status(401).json({ error: 'Current password is incorrect' });
  }
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters' });
  }
  const hash = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?').run(hash, user.id);
  res.json({ ok: true });
});

// Everything below requires a valid admin token
router.use(requireAdmin);

// ---- Bookings ----
router.get('/bookings', (req, res) => {
  res.json(db.prepare('SELECT * FROM bookings ORDER BY created_at DESC').all());
});
router.patch('/bookings/:id', (req, res) => {
  const { status } = req.body || {};
  if (!['confirmed', 'cancelled', 'completed'].includes(status)) {
    return res.status(400).json({ error: 'status must be confirmed, cancelled or completed' });
  }
  db.prepare('UPDATE bookings SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json(db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id));
});

// ---- Members ----
router.get('/members', (req, res) => {
  res.json(db.prepare('SELECT * FROM members ORDER BY created_at DESC').all());
});
router.patch('/members/:id', (req, res) => {
  const { reward, name, phone } = req.body || {};
  const m = db.prepare('SELECT * FROM members WHERE id = ?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'Member not found' });
  db.prepare('UPDATE members SET reward = ?, name = ?, phone = ? WHERE id = ?').run(
    reward != null ? reward : m.reward,
    name || m.name,
    phone !== undefined ? phone : m.phone,
    m.id
  );
  res.json(db.prepare('SELECT * FROM members WHERE id = ?').get(m.id));
});

// ---- Reviews ----
router.get('/reviews', (req, res) => {
  res.json(db.prepare('SELECT * FROM reviews ORDER BY created_at DESC').all());
});
router.patch('/reviews/:id', (req, res) => {
  const { status } = req.body || {};
  if (!['pending', 'approved', 'hidden'].includes(status)) {
    return res.status(400).json({ error: 'status must be pending, approved or hidden' });
  }
  db.prepare('UPDATE reviews SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json(db.prepare('SELECT * FROM reviews WHERE id = ?').get(req.params.id));
});

// ---- Posts ----
router.get('/posts', (req, res) => {
  res.json(db.prepare('SELECT * FROM posts ORDER BY created_at DESC').all());
});
router.patch('/posts/:id', (req, res) => {
  const { status } = req.body || {};
  if (!['approved', 'hidden'].includes(status)) {
    return res.status(400).json({ error: 'status must be approved or hidden' });
  }
  db.prepare('UPDATE posts SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json(db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id));
});
router.delete('/posts/:id', (req, res) => {
  db.prepare('DELETE FROM posts WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---- Stats (dashboard overview) ----
router.get('/stats', (req, res) => {
  const revenue = db.prepare(
    "SELECT COALESCE(SUM(total_paid),0) AS total FROM bookings WHERE status != 'cancelled'"
  ).get().total;
  const bookingCount = db.prepare("SELECT COUNT(*) AS c FROM bookings WHERE status != 'cancelled'").get().c;
  const memberCount = db.prepare('SELECT COUNT(*) AS c FROM members').get().c;
  const pendingReviews = db.prepare("SELECT COUNT(*) AS c FROM reviews WHERE status = 'pending'").get().c;
  const last7 = db.prepare(`
    SELECT date(created_at) AS day, COALESCE(SUM(total_paid),0) AS revenue, COUNT(*) AS bookings
    FROM bookings
    WHERE created_at >= datetime('now','-7 days') AND status != 'cancelled'
    GROUP BY day ORDER BY day ASC
  `).all();
  const topSessions = db.prepare(`
    SELECT session, COUNT(*) AS bookings, COALESCE(SUM(total_paid),0) AS revenue
    FROM bookings WHERE status != 'cancelled'
    GROUP BY session ORDER BY revenue DESC LIMIT 5
  `).all();

  res.json({ revenue, bookingCount, memberCount, pendingReviews, last7, topSessions });
});

module.exports = router;
