const express = require('express');
const router = express.Router();
const db = require('../db');

function genMemberId() {
  return 'KN-' + Math.random().toString(36).substr(2, 5).toUpperCase();
}

// POST /api/members/join  { name, email, phone, location }
router.post('/join', (req, res) => {
  const { name, email, phone, location } = req.body || {};
  if (!name || !email) return res.status(400).json({ error: 'name and email are required' });

  const existing = db.prepare('SELECT * FROM members WHERE lower(email) = lower(?)').get(email);
  if (existing) {
    // Returning member — refresh their details, same as the site's original "update on rejoin" behaviour
    db.prepare('UPDATE members SET name = ?, phone = ?, location = ? WHERE id = ?')
      .run(name, phone || existing.phone, location || existing.location, existing.id);
    return res.json({ ...db.prepare('SELECT * FROM members WHERE id = ?').get(existing.id), returning: true });
  }

  let id;
  do { id = genMemberId(); } while (db.prepare('SELECT 1 FROM members WHERE id = ?').get(id));

  db.prepare('INSERT INTO members (id, name, email, phone, location, reward) VALUES (?, ?, ?, ?, ?, 0)')
    .run(id, name, email, phone || null, location || null);

  res.json(db.prepare('SELECT * FROM members WHERE id = ?').get(id));
});

// GET /api/members/lookup?email=...
router.get('/lookup', (req, res) => {
  const { email } = req.query;
  if (!email) return res.status(400).json({ error: 'email query param required' });
  const member = db.prepare('SELECT * FROM members WHERE lower(email) = lower(?)').get(email);
  if (!member) return res.status(404).json({ error: 'No membership found for that email' });
  res.json(member);
});

module.exports = router;
