const express = require('express');
const router = express.Router();
const db = require('../db');

// POST /api/bookings
// Body: { name, email, phone, paymentMethod, promoCode, useReward, items: [{session,date,time,qty,unitTotal,flat}] }
// Pricing (discount / reward earn / reward redeem) is computed SERVER-SIDE from the
// member record — never trust totals sent by the browser, since anyone can edit
// client-side JS in devtools before checkout.
router.post('/', (req, res) => {
  const { name, email, phone, paymentMethod, promoCode, useReward, items } = req.body || {};

  if (!name || !email || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'name, email and at least one item are required' });
  }
  for (const it of items) {
    if (!it.session || !it.date || !it.time || typeof it.unitTotal !== 'number') {
      return res.status(400).json({ error: 'Each item needs session, date, time, unitTotal' });
    }
  }

  const member = db.prepare('SELECT * FROM members WHERE lower(email) = lower(?)').get(email);
  const baseTotal = items.reduce((s, it) => s + it.unitTotal, 0);
  const discount = member ? +(baseTotal * 0.03).toFixed(2) : 0;
  let afterDiscount = +(baseTotal - discount).toFixed(2);

  let rewardUsed = 0;
  if (member && useReward) {
    rewardUsed = +Math.min(member.reward, afterDiscount).toFixed(2);
    afterDiscount = +(afterDiscount - rewardUsed).toFixed(2);
  }
  const rewardEarned = member ? +(afterDiscount * 0.03).toFixed(2) : 0;

  const insertBooking = db.prepare(`
    INSERT INTO bookings
      (customer_name, customer_email, customer_phone, session, date, time, qty,
       base_total, discount, reward_used, reward_earned, total_paid,
       payment_method, promo_code, member_id, status)
    VALUES (@customer_name, @customer_email, @customer_phone, @session, @date, @time, @qty,
            @base_total, @discount, @reward_used, @reward_earned, @total_paid,
            @payment_method, @promo_code, @member_id, 'confirmed')
  `);

  const bookingIds = [];
  const tx = db.transaction(() => {
    items.forEach((it) => {
      const share = baseTotal > 0 ? it.unitTotal / baseTotal : 0;
      const info = insertBooking.run({
        customer_name: name,
        customer_email: email,
        customer_phone: phone || null,
        session: it.session,
        date: it.date,
        time: it.time,
        qty: it.flat ? '—' : String(it.qty ?? ''),
        base_total: it.unitTotal,
        discount: +(discount * share).toFixed(2),
        reward_used: +(rewardUsed * share).toFixed(2),
        reward_earned: +(rewardEarned * share).toFixed(2),
        total_paid: +((it.unitTotal - discount * share - rewardUsed * share)).toFixed(2),
        payment_method: paymentMethod || null,
        promo_code: promoCode || null,
        member_id: member ? member.id : null,
      });
      bookingIds.push(info.lastInsertRowid);
    });

    if (member) {
      db.prepare('UPDATE members SET reward = reward - ? + ? WHERE id = ?')
        .run(rewardUsed, rewardEarned, member.id);
    }
  });
  tx();

  const updatedMember = member
    ? db.prepare('SELECT * FROM members WHERE id = ?').get(member.id)
    : null;

  res.json({
    ok: true,
    bookingIds,
    totalPaid: +(afterDiscount).toFixed(2),
    discount,
    rewardUsed,
    rewardEarned,
    member: updatedMember,
  });
});

// GET /api/bookings/by-email/:email  — lets a customer see their bookings from any device
router.get('/by-email/:email', (req, res) => {
  const rows = db.prepare(
    'SELECT * FROM bookings WHERE lower(customer_email) = lower(?) ORDER BY created_at DESC'
  ).all(req.params.email);
  res.json(rows);
});

module.exports = router;
