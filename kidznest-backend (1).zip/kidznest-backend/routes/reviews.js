const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/reviews — public, approved only
router.get('/', (req, res) => {
  const rows = db.prepare(
    "SELECT id, name, rating, text, created_at FROM reviews WHERE status = 'approved' ORDER BY created_at DESC"
  ).all();
  res.json(rows);
});

// POST /api/reviews — goes to 'pending' for moderation before it appears publicly
router.post('/', (req, res) => {
  const { name, rating, text } = req.body || {};
  if (!name || !text || !rating) return res.status(400).json({ error: 'name, rating and text are required' });
  const r = Number(rating);
  if (!(r >= 1 && r <= 5)) return res.status(400).json({ error: 'rating must be 1-5' });

  const info = db.prepare(
    "INSERT INTO reviews (name, rating, text, status) VALUES (?, ?, ?, 'pending')"
  ).run(name, r, text);

  res.json({ ok: true, id: info.lastInsertRowid, status: 'pending' });
});

module.exports = router;
