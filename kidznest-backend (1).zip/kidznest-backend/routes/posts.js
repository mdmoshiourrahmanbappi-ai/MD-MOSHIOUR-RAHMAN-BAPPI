const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/posts — approved posts with their comments
router.get('/', (req, res) => {
  const posts = db.prepare(
    "SELECT * FROM posts WHERE status = 'approved' ORDER BY created_at DESC"
  ).all();
  const commentStmt = db.prepare('SELECT * FROM comments WHERE post_id = ? ORDER BY created_at ASC');
  const withComments = posts.map((p) => ({ ...p, comments: commentStmt.all(p.id) }));
  res.json(withComments);
});

// POST /api/posts  { authorName, content, imageUrl }
router.post('/', (req, res) => {
  const { authorName, content, imageUrl } = req.body || {};
  if (!authorName || !content) return res.status(400).json({ error: 'authorName and content are required' });
  const info = db.prepare(
    "INSERT INTO posts (author_name, content, image_url, status) VALUES (?, ?, ?, 'approved')"
  ).run(authorName, content, imageUrl || null);
  res.json(db.prepare('SELECT * FROM posts WHERE id = ?').get(info.lastInsertRowid));
});

// POST /api/posts/:id/comments  { authorName, content }
router.post('/:id/comments', (req, res) => {
  const { authorName, content } = req.body || {};
  if (!authorName || !content) return res.status(400).json({ error: 'authorName and content are required' });
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });
  const info = db.prepare(
    'INSERT INTO comments (post_id, author_name, content) VALUES (?, ?, ?)'
  ).run(post.id, authorName, content);
  res.json(db.prepare('SELECT * FROM comments WHERE id = ?').get(info.lastInsertRowid));
});

module.exports = router;
