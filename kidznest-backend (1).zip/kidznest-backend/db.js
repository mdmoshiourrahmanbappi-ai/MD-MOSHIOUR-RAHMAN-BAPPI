// db.js — SQLite database setup for Kidz Nest Play Café
// Swap-out note: if you outgrow SQLite (heavy concurrent traffic, multi-server hosting),
// the schema below maps 1:1 onto Postgres. See README "Scaling to Postgres" section.

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = path.join(DATA_DIR, 'kidznest.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS members (
  id TEXT PRIMARY KEY,              -- e.g. KN-AB3F9
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT,
  location TEXT,
  reward REAL NOT NULL DEFAULT 0,   -- loyalty balance in GBP
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT,
  session TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  qty TEXT,                         -- number of children, or '—' for flat-rate items
  base_total REAL NOT NULL,
  discount REAL NOT NULL DEFAULT 0,
  reward_used REAL NOT NULL DEFAULT 0,
  reward_earned REAL NOT NULL DEFAULT 0,
  total_paid REAL NOT NULL,
  payment_method TEXT,
  promo_code TEXT,
  member_id TEXT REFERENCES members(id),
  status TEXT NOT NULL DEFAULT 'confirmed',  -- confirmed | cancelled | completed
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  text TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',  -- pending | approved | hidden
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author_name TEXT NOT NULL,
  content TEXT NOT NULL,
  image_url TEXT,
  status TEXT NOT NULL DEFAULT 'approved', -- approved | hidden
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_name TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS admin_users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// Seed a default admin user on first run only (change password immediately after first login).
const adminCount = db.prepare('SELECT COUNT(*) AS c FROM admin_users').get().c;
if (adminCount === 0) {
  const defaultPassword = process.env.ADMIN_DEFAULT_PASSWORD || 'ChangeMe123!';
  const hash = bcrypt.hashSync(defaultPassword, 10);
  db.prepare('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)')
    .run('admin', hash);
  console.log('----------------------------------------------------------');
  console.log('Created default admin user:');
  console.log('  username: admin');
  console.log('  password:', defaultPassword);
  console.log('CHANGE THIS after first login (see README).');
  console.log('----------------------------------------------------------');
}

module.exports = db;
