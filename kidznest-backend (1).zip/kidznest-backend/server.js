require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

// ---- CORS ----
// ALLOWED_ORIGINS is a comma-separated list, e.g.
//   ALLOWED_ORIGINS=https://www.kidznestplaycafe.co.uk,https://kidznestplaycafe.co.uk
// Until you set it, this falls back to allowing any origin, which is fine for local
// testing but should NOT be left that way once this is handling real bookings —
// see README "Security checklist before launch".
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

app.use(cors({
  origin: allowedOrigins.length
    ? function (origin, callback) {
        // requests with no origin (curl, server-to-server, some mobile webviews) are allowed
        if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
        callback(new Error('Not allowed by CORS'));
      }
    : true, // no ALLOWED_ORIGINS set yet — allow all (development default)
}));

// Stripe's webhook needs the raw, unparsed request body to verify the signature,
// so it must be registered BEFORE express.json() and excluded from JSON parsing.
app.use('/api/webhooks', express.raw({ type: 'application/json' }), require('./routes/webhooks'));

app.use(express.json());

app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/members', require('./routes/members'));
app.use('/api/reviews', require('./routes/reviews'));
app.use('/api/posts', require('./routes/posts'));
app.use('/api/checkout', require('./routes/checkout'));
app.use('/api/admin', require('./routes/admin'));

// Serves the admin dashboard at /admin
app.use('/admin', express.static(path.join(__dirname, 'public', 'admin')));

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Kidz Nest backend running on port ${PORT}`));
