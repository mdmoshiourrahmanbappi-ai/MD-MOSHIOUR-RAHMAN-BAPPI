# Kidz Nest Play Café — Backend & Admin Dashboard

This is the backend for kidznestplaycafe.co.uk. It replaces the old
localStorage-only demo with a real database, a REST API, real Stripe
payments, and an admin dashboard at `/admin`.

## What's in here

```
kidznest-backend/
  server.js          Express app entry point
  db.js              SQLite schema + setup (auto-creates tables & admin user on first run)
  routes/
    bookings.js      Create bookings, look up a customer's bookings by email
    members.js       Join / look up free membership
    reviews.js       Public approved reviews + new review submissions (go to moderation)
    posts.js         Community feed posts + comments
    checkout.js      Creates a Stripe Checkout session (real payments)
    webhooks.js      Stripe calls this after payment — this is what actually creates the booking
    admin.js         Everything behind login: manage bookings/members/reviews/posts, stats
  middleware/auth.js Token check for admin routes
  public/admin/      The admin dashboard (plain HTML/JS, no build step)
  data/kidznest.db   The SQLite database file (created automatically — do not commit it)
```

## Running it locally

Requires Node.js 18+.

```bash
cd kidznest-backend
npm install
cp .env.example .env      # then edit .env — see below
node server.js
```

You'll see a one-time message with a default admin login:

```
username: admin
password: ChangeMe123!
```

Visit `http://localhost:3000/admin`, log in, and immediately go to
**Settings → Change admin password**.

### Environment variables (`.env`)

| Variable | What it's for |
|---|---|
| `PORT` | Port to listen on (hosts like Render set this for you) |
| `JWT_SECRET` | Long random string that signs admin login sessions. Generate with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `ADMIN_DEFAULT_PASSWORD` | Only used the very first time the server runs, to create the `admin` account |
| `ALLOWED_ORIGINS` | Comma-separated list of domains allowed to call this API. Leave blank locally; **set before launch** — see security checklist |
| `STRIPE_SECRET_KEY` | From Stripe Dashboard → Developers → API keys. Only needed once you're ready for real payments |
| `STRIPE_WEBHOOK_SECRET` | From Stripe Dashboard → Developers → Webhooks, after adding an endpoint (see "Stripe payments" below) |

## Connecting your existing website

The website file (`kidznest-frontend.html`, already wired up) talks to
this backend through a small `knApi()` helper near the top of its
`<script>` tag:

```js
var KN_API_BASE = '';
```

- Leave it as `''` if the backend is served from the **same domain** as
  the website.
- Set it to a full URL (e.g. `'https://api.kidznestplaycafe.co.uk'`) if
  you host the API on a separate subdomain.

## What changed on the website itself

- **Bookings** save to the database via the backend, with pricing
  (membership discount, reward redeemed/earned) calculated **server-side**
  — the browser can no longer edit the page's JavaScript to change the
  price before paying, which the original demo was vulnerable to.
- **Payment is real.** Clicking "Continue to Secure Payment" now creates a
  Stripe Checkout Session and redirects the customer to Stripe's own
  hosted payment page (card, Apple Pay, Google Pay). Kidz Nest's server
  never sees a card number. The booking record is only created after
  Stripe confirms the charge — see "Stripe payments" below.
- **My Bookings** looks a customer's bookings up by email from the
  database, so they show up on any device.
- **Membership** join/lookup uses the database, so a member's reward
  balance is the same everywhere.
- **Reviews** submitted on the site go into a moderation queue instead of
  appearing instantly. Approve them from the dashboard's Reviews tab.

---

## Deploying (step by step, ~15 minutes)

SQLite (the database used here) is a single file, so the server needs a
platform with a **persistent disk** — not a purely serverless one. Render
is the easiest free option; Railway is a close second. Steps below are
for Render; Railway is nearly identical (noted where it differs).

1. **Push this folder to GitHub.** Create a new repo (public or private)
   and push the contents of `kidznest-backend/` to it. (`.gitignore` is
   already set up to skip `node_modules` and the database file.)

2. **Create the service on Render.** Go to render.com → New → Web
   Service → connect the GitHub repo. Set:
   - **Build command:** `npm install`
   - **Start command:** `node server.js`
   - **Instance type:** Free is fine to start

   *(Railway: New Project → Deploy from GitHub repo — it auto-detects
   the build/start commands from `package.json`.)*

3. **Add a persistent disk.** In the service's Settings → Disks, add a
   1 GB disk mounted at `/opt/render/project/src/data` (this is where
   `data/kidznest.db` lives). Without this, the database resets every
   time the service restarts or redeploys.

   *(Railway: Settings → Volumes, mount at `/app/data`.)*

4. **Set environment variables.** In the service's Environment tab, add
   everything from `.env.example`: `JWT_SECRET` (generate a real random
   one — see the table above), `ADMIN_DEFAULT_PASSWORD`, and
   `ALLOWED_ORIGINS` set to your real site domain(s). Leave the Stripe
   variables blank for now if you're not ready for real payments yet.

5. **Deploy and grab the URL.** Render gives you a URL like
   `https://kidznest-backend.onrender.com`. Visit `<that-url>/admin`,
   log in with the default password from step 4, and change it
   immediately (Settings tab).

6. **Point the website at it.** In `kidznest-frontend.html`, set
   `KN_API_BASE` to that URL (unless the website is served from the same
   domain as the backend). Re-upload the website file wherever it's
   hosted.

7. **Test the full loop** once more from the live URLs: join membership,
   make a booking, submit a review, then check the admin dashboard shows
   all three.

That's the backend live. The steps below (Stripe, CORS lockdown) can be
done any time after this — the site works and takes real bookings even
before Stripe is switched on, it just won't be able to charge a card
until step "Stripe payments" is done.

## Scaling to Postgres (only needed once you have real traffic)

SQLite comfortably handles a single-location play café's booking volume.
If you ever need it, the schema in `db.js` maps directly onto Postgres —
swap `better-sqlite3` for `pg`, adjust the `CREATE TABLE` syntax slightly
(mainly `AUTOINCREMENT` → `SERIAL`, and `datetime('now')` → `now()`), and
the rest of the app (routes, admin dashboard) doesn't need to change.

---

## Stripe payments (already wired in — just needs your account)

The checkout flow is built and working; you just need a Stripe account
connected to it.

1. **Create a Stripe account** at stripe.com if you don't have one.
   You'll start in **test mode** — good for trying the whole flow safely
   with fake card numbers before taking real money.

2. **Get your test API key.** Stripe Dashboard → Developers → API keys →
   copy the "Secret key" (starts `sk_test_...`). Put it in your `.env`
   (or your host's environment variables) as `STRIPE_SECRET_KEY`.

3. **Add a webhook endpoint.** Stripe Dashboard → Developers → Webhooks →
   Add endpoint. URL: `https://<your-backend-url>/api/webhooks/stripe`.
   Select the event `checkout.session.completed`. After creating it,
   Stripe shows a "Signing secret" (starts `whsec_...`) — put that in
   `STRIPE_WEBHOOK_SECRET`.

4. **Restart the server** (or redeploy) so it picks up the new
   environment variables.

5. **Test it.** Make a booking on the live site and use one of Stripe's
   test card numbers (`4242 4242 4242 4242`, any future expiry, any CVC).
   You should land back on the site with a confirmation, and the booking
   should appear in the admin dashboard's Bookings tab with payment
   method "stripe".

6. **Go live.** Once you're happy, switch Stripe's dashboard toggle from
   "Test mode" to "Live mode", repeat steps 2–3 to get **live** keys
   (they start `sk_live_...` / a live webhook secret), and update your
   environment variables with those instead. Real cards will now be
   charged.

### How the flow works, briefly

- The website asks the backend to create a Stripe **Checkout Session**
  (`POST /api/checkout/create-session`), which calculates the price
  server-side (same anti-tampering logic as regular bookings) and
  returns a Stripe-hosted payment page URL.
- The customer pays on Stripe's own page — this server and site never
  see the card number.
- Stripe calls the backend's webhook (`POST /api/webhooks/stripe`) once
  the payment succeeds, and **that's** what actually writes the booking
  to the database and updates the member's reward balance. This matters
  because it means a booking can never be recorded as paid unless Stripe
  actually confirms the money moved — nobody can fake a "success" URL to
  get a free booking.
- Refunds, disputes, and viewing raw payment records happen in the
  Stripe Dashboard for now. A "cancel and refund" button inside the
  admin dashboard here would be a reasonable next addition once you're
  taking live payments regularly.

---

## Security checklist before launch

Go through these in order before this handles real customers and real
payments:

- [ ] **Change the default admin password** (Settings tab in `/admin`) —
      do this the moment you first deploy, don't wait.
- [ ] **Set a real, random `JWT_SECRET`** in production. Generate one
      with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
      — never reuse the placeholder value from `.env.example`.
- [ ] **Set `ALLOWED_ORIGINS`** to your real site domain(s) once the
      website's final domain is known. Until this is set, the API
      accepts requests from any website, which is fine for testing but
      means another site could embed calls to your booking API.
- [ ] **Use Stripe's live keys only when ready to take real money** — a
      live key left in a test deployment means real cards could be
      charged accidentally; a test key left in production means nobody
      can actually pay.
- [ ] **Keep `STRIPE_WEBHOOK_SECRET` set correctly** — without it, the
      webhook handler rejects Stripe's requests (safe default, but it
      means no bookings get created after payment, so double check this
      after every deploy where you touch environment variables).
- [ ] **Never commit `.env` or `data/kidznest.db` to git** — both are
      already in `.gitignore`, just don't force-add them.
- [ ] **Back up `data/kidznest.db` regularly** — a daily copy to cloud
      storage (or Render's/Railway's own disk snapshots, if available on
      your plan) is enough for a business this size.
- [ ] **Review the admin dashboard's exposed surface** — it's a single
      shared login (`admin`) for now, which is fine for a one-person or
      small-team operation. If more than one person needs access with
      different permission levels later, that's a reasonable future
      addition (separate accounts, roles) rather than something to
      retrofit under pressure.
